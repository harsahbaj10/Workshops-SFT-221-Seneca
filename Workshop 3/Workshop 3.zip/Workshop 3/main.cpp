#define _CRT_SECURE_NO_WARNING

#include <iostream>
#include "customer.h"

using namespace std;
using namespace harsahbajSft3;

int main(void)
{
	readInfo();
	display();
	return 0;
}